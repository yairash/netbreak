/* localStorage */

let filePaths = localStorage;